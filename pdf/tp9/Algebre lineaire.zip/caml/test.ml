dim a, dim b, dim c;;
base a, base b, base c;;
noyau a;;
somme a b;;
somme a c;;
inters a b;;
Array.map (Array.map string_of_num) (inters a c);;
orth a;;
orth b;;
orth c;;

